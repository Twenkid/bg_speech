// VoiceText.h: interface for the CVoiceText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOICETEXT_H__6A935C64_88B9_11D7_9A4A_000000000000__INCLUDED_)
#define AFX_VOICETEXT_H__6A935C64_88B9_11D7_9A4A_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVoiceText  
{
public:
	int SetPosition(DWORD pos);
	DWORD GetPosition();
	int WordForth(int count);
	int WordBack(int count);
	int SentenceForth(int count);
	int SentenceBack(int count);
	void Empty();
	int GetWord(CString &strWord);
	int SetString(CString &string);
	int SetString(char *pstring);
	int SetText(char *ptext,int textsize);
	CVoiceText();
	virtual ~CVoiceText();
protected:
	void FreeText();
	void FreeTempText();
	int GetTempWord(CString &strWord);
	int IsNumber(char c);
	int IsCyrillic(char c);
	int CanIgnore(char c);
	char		*m_pText;
	int			m_iTextSize;
	int			m_iTextPtr;
	char		*m_pTempText;
	int			m_iTempTextSize;
	int			m_iTempTextPtr;
	int			m_bTemp;
};

#endif // !defined(AFX_VOICETEXT_H__6A935C64_88B9_11D7_9A4A_000000000000__INCLUDED_)
