#if !defined(AFX_VOICE_H__CC70A294_858B_11D7_9A3D_000000000000__INCLUDED_)
#define AFX_VOICE_H__CC70A294_858B_11D7_9A3D_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Voice.h : header file
//
#include "VoiceText.h"
#include <mmsystem.h>
#include <Afxmt.h>

#define WM_VOICE_PLAY			WM_USER + 1
#define WM_VOICE_STOP			WM_USER + 2

#define VOICE_MAXITEMS		512
#define VOICE_MAXWORD		40
#define VOICE_DT			'VDr1'
#define PHONEME_MAXCHARS	7

#define VOICE_DEVMODE

typedef  struct tagDS_VOICE{
DWORD				dwDT;
DWORD				dwChannels;
DWORD				dwSPS;
DWORD				dwBPS;
DWORD				dwNumber;
DWORD				dwType;
char				name[32];
DWORD				reserved[6];
}DS_VOICE, *PDS_VOICE;

typedef  struct tagDS_VITEM{
char		text[8];
char		wave[24];
}DS_VITEM, *PDS_VITEM;

/////////////////////////////////////////////////////////////////////////////
// CVoice thread

class CVoice : public CWinThread
{
	DECLARE_DYNCREATE(CVoice)
protected:
//	CVoice();           // protected constructor used by dynamic creation

// Attributes
public:
#if defined(VOICE_DEVMODE)
	int SaveVoice();
	int AddItem(CString &itext);
	int GetItemText(CString &itext,int item);
	int GetItemWave(CString &itext,int item);
	int GetItemCount();
	int MakeNew(CString &location,CString &name,DWORD channels,DWORD sps,DWORD bps,DWORD type,DWORD copy=0);
#endif
	int LoadVoice(const CString &vfile);
	void ReleseVoice();
	CVoice();
	virtual ~CVoice();

// Operations
public:
	int SetMaxCh(DWORD maxch);
	int SetOverlap(DWORD size);
	int SetPosition(DWORD pos);
	DWORD GetPosition();
	DWORD GetSPS();
	DWORD GetBPS();
	int SentenceForth(int count);
	int SentenceBack(int count);
	int WordForth(int count);
	int WordBack(int count);
	int RemoveItem(DWORD item);
	int Stop();
	int Start();
	int SetString(CString &string);
	int SetString(char *pstring);
	int SetText(char *ptext,int textsize);
	int GetTextIndex(CString &itext);
	int GetVoiceFileName(CString &vddname);
	int GetVoiceName(CString &vname);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoice)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	int StopSync();
	int SayWord(CString &word);
	void* LoadWave(int item,DWORD &samples);
	int WaveOut(void *wdata,DWORD size);
	int IsReady();
	DS_VITEM	*m_pItems;
	DS_VOICE	m_dsVoice;
	CString		m_vddname;
	CVoiceText	m_text;
	UINT		m_WaveDevice;
	HWAVEOUT	m_hWaveOut;
	void		*m_pWBuffer;
	WAVEHDR		m_tagWaveHdr;
	int			m_bStop;
	int			m_bStarted;
	int			m_iPause1;
	int			m_iPause2;
	DWORD		m_dwOverlap;
	int			m_iMaxChars;
//	CCriticalSection m_crs;
//	virtual ~CVoice();

	// Generated message map functions
	//{{AFX_MSG(CVoice)
		// NOTE - the ClassWizard will add and remove member functions here.
		afx_msg void On_MM_WOM_DONE(UINT parm1, LONG parm2);
		afx_msg void On_WM_VOICE_STOP(UINT parm1, LONG parm2);
		afx_msg void On_WM_VOICE_PLAY(UINT parm1, LONG parm2);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOICE_H__CC70A294_858B_11D7_9A3D_000000000000__INCLUDED_)
