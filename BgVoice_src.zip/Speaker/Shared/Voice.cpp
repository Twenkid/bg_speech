// Voice.cpp : implementation file
//

#include "stdafx.h"
#include "Voice.h"
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

char *eq[32]={"a","b","w","g","d","e","v","z","i","j","k","l","m","n","o","p","r","s","t","u","f","h","c","ch","sh","sht","y","q","x","eo","iu","ia"};
/////////////////////////////////////////////////////////////////////////////
// CVoice

IMPLEMENT_DYNCREATE(CVoice, CWinThread)

CVoice::CVoice()
{
	CreateThread();
	m_WaveDevice=WAVE_MAPPER;
	m_hWaveOut=0;
	m_pItems=NULL;
	m_pWBuffer=0;
	m_bStop=0;
	m_iPause1=80;
	m_iPause2=100;
	m_dwOverlap=500;
	m_iMaxChars=PHONEME_MAXCHARS;
	m_bStarted=0;
	ReleseVoice();
}

CVoice::~CVoice()
{
	StopSync();
	ReleseVoice();
	if(m_pWBuffer) free(m_pWBuffer);
	m_pWBuffer=0;
}

BOOL CVoice::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	return TRUE;
}

int CVoice::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CVoice, CWinThread)
	//{{AFX_MSG_MAP(CVoice)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		ON_THREAD_MESSAGE(MM_WOM_DONE, On_MM_WOM_DONE)
		ON_THREAD_MESSAGE(WM_VOICE_PLAY, On_WM_VOICE_PLAY)
		ON_THREAD_MESSAGE(WM_VOICE_STOP, On_WM_VOICE_STOP)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVoice message handlers
void CVoice::On_MM_WOM_DONE(UINT parm1, LONG parm2)
{

	HWAVEOUT hwo =	(HWAVEOUT) parm1;
	WAVEHDR* pWaveHdr = (LPWAVEHDR) parm2;

		if (pWaveHdr && hwo) {
			if (pWaveHdr->dwFlags & WHDR_DONE == WHDR_DONE) {
				pWaveHdr->dwFlags = 0;
				waveOutUnprepareHeader(hwo, pWaveHdr, sizeof(WAVEHDR));
			}
		}
		waveOutClose(m_hWaveOut);
		m_hWaveOut=0;
		
		if(!m_bStop){
		PostThreadMessage(WM_VOICE_PLAY,0,0);
		}
		else{
			m_bStarted=0;
		}
	return;

}
void CVoice::On_WM_VOICE_PLAY(UINT parm1, LONG parm2)
{
	CString tstr;
	if(m_bStop){
		if(StopSync()){
			m_bStarted=0;
			return;
		}
	}
	if(m_text.GetWord(tstr)){
		if(tstr.IsEmpty()) {
			Sleep(m_iPause2);	
			PostThreadMessage(WM_VOICE_PLAY,0,0);
		}
		else {
			Sleep(m_iPause1);	
			SayWord(tstr);
		}
	}
	else{
		//if(StopSync()){
			m_bStarted=0;
			return;
		//}
	}
}
void CVoice::On_WM_VOICE_STOP(UINT parm1, LONG parm2)
{
}

void CVoice::ReleseVoice()
{
	StopSync();
	ZeroMemory(&m_dsVoice,sizeof(DS_VOICE));
	if(m_pItems) free(m_pItems);
	m_vddname.Empty();
}

int CVoice::LoadVoice(const CString &vfile)
{
	if(!StopSync()) return 0;
	CString fname=vfile;
	if(fname.IsEmpty()) return 0;
	fname.MakeLower();
	if(fname.Right(9)!="voice.vdd"){
		::MessageBox(0,"Not a voice file!","Error!",MB_OK|MB_TOPMOST);
		return 0;
	}

	CFile file;
	int l,ds,err=0;
	if(file.Open(fname, CFile::modeRead))
	{
	ReleseVoice();
		if((l=file.Read(&m_dsVoice,sizeof(DS_VOICE)))==sizeof(DS_VOICE)){
			if(m_dsVoice.dwDT!=VOICE_DT)							{::MessageBox(0,"Not a voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
			if(m_dsVoice.dwNumber>VOICE_MAXITEMS)					{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
#if !defined(VOICE_DEVMODE)
			if(m_dsVoice.dwNumber<1)								{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
#endif
			if(m_dsVoice.dwChannels>2)								{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
			if((m_dsVoice.dwSPS<11025)||(m_dsVoice.dwSPS>44100))	{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
			if((m_dsVoice.dwBPS!=8)&&(m_dsVoice.dwBPS!=16))			{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
			if(m_dsVoice.dwType!=1)									{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}
		}
		else	{::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); err=1;}

		ds=m_dsVoice.dwNumber*sizeof(DS_VITEM);
#if defined(VOICE_DEVMODE)
		m_pItems=(DS_VITEM*)malloc(VOICE_MAXITEMS*sizeof(DS_VITEM));
#else
		m_pItems=(DS_VITEM*)malloc(ds);
#endif
		if(m_pItems){
			if(ds){
				if((l=file.Read(m_pItems,ds))!=ds){
				::MessageBox(0,"Corrupted voice file!","Error!",MB_OK|MB_TOPMOST); 
				err=1;
				}
			}
		}
		else	{::MessageBox(0,"Not enough memory!","Error!",MB_OK|MB_TOPMOST); err=1;}
	file.Close();
	}
	else
	::MessageBox(0,"File not found!","Error!",MB_OK|MB_TOPMOST);

	if(err!=0){
		ReleseVoice();
		return 0;
	}
	else{
		m_vddname=fname;
	}
	return 1;
}

int CVoice::SayWord(CString &word)
{
	if(!IsReady()) return 0;
	CString sword=word;
	if(sword.IsEmpty()) return 0;
	if(sword.GetLength()>VOICE_MAXWORD) sword=sword.Left(VOICE_MAXWORD);
	sword.MakeLower();

	int ids[VOICE_MAXWORD],bestid,is,maxeq,twl,phl;
	DWORD i,idi=0;
	char ci;
	phl=m_iMaxChars;
	while(!sword.IsEmpty()){
		twl=sword.GetLength();
		maxeq=0;
		bestid=-1;
		for(i=0;i<m_dsVoice.dwNumber;i++){
			for(is=0;is<phl;is++){
				if(is>=twl)			break;
				ci=m_pItems[i].text[is];
				if(ci==0)			break;
				if(ci!=sword[is])	break;
				if((is+1)>maxeq) {
					bestid=i;
					maxeq=is+1;
				}
			}
		}
		if(bestid>=0){
			ids[idi]=bestid;
			idi=idi+1;
			sword=sword.Right(sword.GetLength()-maxeq);
		}
		else{
			sword=sword.Right(sword.GetLength()-1);
		}
	}
	if(idi<=0) return 0;
	BYTE *wdata[VOICE_MAXWORD];
	DWORD  wsize[VOICE_MAXWORD],numw=0;

	for(i=0;i<idi;i++){
		if((wdata[numw]=(BYTE*)LoadWave(ids[i],wsize[numw]))!=0)
			numw=numw+1;
	}
	if(numw==0) return 0;

	DWORD fwsize=0;
	for(i=0;i<numw;i++){
		fwsize=fwsize+wsize[i];
	}

	fwsize=fwsize*((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels);
	if(m_pWBuffer) free(m_pWBuffer);
	m_pWBuffer=malloc(fwsize);
	if(!m_pWBuffer) {
		for(i=0;i<numw;i++){
			free(wdata[i]);
		}
		return 0;
	}
	
	BYTE *ptwb;
	DWORD twbo=0,twbs,tws;
	ptwb=(BYTE*)m_pWBuffer;
	
	if(m_dwOverlap){
		DWORD over,iso;
		int ts1,ts2;
		short	*p16_1,*p16_2;
		BYTE	*p8_1,*p8_2;
		for(i=0;i<numw;i++){
			twbs=wsize[i]*((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels);
			if(i==0)	MoveMemory(ptwb+twbo,wdata[i],twbs);
			else{
				over=m_dwOverlap;
				over=over*44100/m_dsVoice.dwSPS;
				if(over>wsize[i])	over=wsize[i];

				tws=twbo/((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels);
				if(tws<over)				over=tws;
				if(over>wsize[i]/12) over=wsize[i]/12;
				if(over>wsize[i-1]/12) over=wsize[i-1]/12;
				if((m_dsVoice.dwBPS>>3)==1){
					p8_1=(BYTE*)(ptwb+(tws-over));
					p8_2=(BYTE*)(wdata[i]);
					for(iso=0;iso<over;iso++){
						ts1=*(p8_1+iso)-128;
						ts2=*(p8_2+iso)-128;
						ts1=ts1+ts2+128;
						if(ts1<0) ts1=0;
						if(ts1>255) ts1=255;
						*(p8_1+iso)=(BYTE)ts1;
					}
					for(iso=over;iso<wsize[i];iso++){
						*(p8_1+iso)=*(p8_2+iso);
					}
				}
				if((m_dsVoice.dwBPS>>3)==2){
					p16_1=(((short*)ptwb)+(tws-over));
					p16_2=(short*)(wdata[i]);
					for(iso=0;iso<over;iso++){
						ts1=*(p16_1+iso);
						ts2=*(p16_2+iso);
						ts1=ts1+ts2;
						if(ts1>32767) ts1=32767;
						if(ts1<-32767) ts1=-32767;
						*(p16_1+iso)=(short)ts1;
					}
					for(iso=over;iso<wsize[i];iso++){
						*(p16_1+iso)=*(p16_2+iso);
					}
				}
			twbs=(wsize[i]-over)*((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels);
			}
			twbo=twbo+twbs;
			free(wdata[i]);
		}

	}
	else{
		for(i=0;i<numw;i++){
			twbs=wsize[i]*((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels);
			MoveMemory(ptwb+twbo,wdata[i],twbs);
			twbo=twbo+twbs;
			free(wdata[i]);
		}
	}
	WaveOut(m_pWBuffer,twbo);
	return 0;
}

#if defined(VOICE_DEVMODE)

int CVoice::MakeNew(CString &location,CString &name, DWORD channels, DWORD sps, DWORD bps, DWORD type, DWORD copy)
{
	if(!StopSync()) return 0;
	int err=0;

	if((copy)&&((!IsReady())||(m_dsVoice.dwNumber==0)))  {::MessageBox(0,"No active voice!","Error!",MB_OK|MB_TOPMOST); err=1;}
	CString fname=location;
	if(fname.IsEmpty())		{::MessageBox(0,"Wrong location!","Error!",MB_OK|MB_TOPMOST); err=1;}
	CString vname=name;
	if(vname.IsEmpty())		{::MessageBox(0,"Wrong name!","Error!",MB_OK|MB_TOPMOST); err=1;}
	if(vname.GetLength()>30){::MessageBox(0,"Wrong name!","Error!",MB_OK|MB_TOPMOST); err=1;}

	if((channels>2)||(channels<1))	{::MessageBox(0,"Wrong channels number!","Error!",MB_OK|MB_TOPMOST); err=1;}
	if((sps<11025)||(sps>44100))	{::MessageBox(0,"Wrong sample rate!","Error!",MB_OK|MB_TOPMOST); err=1;}
	if((bps<8)||(bps>16))			{::MessageBox(0,"Wrong quality!","Error!",MB_OK|MB_TOPMOST); err=1;}
	if(type!=1)						{::MessageBox(0,"Wrong type!","Error!",MB_OK|MB_TOPMOST); err=1;}

	if(err) return 0;

	CFileFind ff; 
	CString tstr;
	BOOL found=FALSE;
	tstr=fname+"\\"+vname;
	found=ff.FindFile(tstr);
	if(found){
	::MessageBox(0,"The specifyed voice already exist. Please use unique voice name.","Error!",MB_OK|MB_TOPMOST);
	return 0;
	}
	else{
		_mkdir(LPCTSTR(fname));
		_mkdir(LPCTSTR(tstr));
	}

	CFile file;
	tstr=fname+"\\"+vname+"\\"+"voice.vdd";
	if(file.Open(tstr, CFile::modeCreate|CFile::modeWrite)){
		if(!copy){
		ReleseVoice();
		m_pItems=(DS_VITEM*)malloc(VOICE_MAXITEMS*sizeof(DS_VITEM));
		ZeroMemory(m_pItems,sizeof(DS_VITEM));
		}
		if(m_pItems){
		strcpy(m_dsVoice.name,vname);
		m_dsVoice.dwDT=VOICE_DT;
		m_dsVoice.dwChannels=channels;
		m_dsVoice.dwSPS=sps;
		m_dsVoice.dwBPS=bps;
		m_dsVoice.dwType=type;
		if(!copy) m_dsVoice.dwNumber=0;
		file.Write(&m_dsVoice,sizeof(DS_VOICE));
		if(copy) file.Write(m_pItems,sizeof(DS_VITEM)*m_dsVoice.dwNumber);
		m_vddname=fname;
		}
		else{
		::MessageBox(0,"Not enough memory!","Error!",MB_OK|MB_TOPMOST); 
		ReleseVoice();
		return 0;
		}
	file.Close();
	return 1;
	}
	::MessageBox(0,"Can't create voice file.","Error!",MB_OK|MB_TOPMOST);
	return 0;
}	

int CVoice::GetItemCount()
{
	return m_dsVoice.dwNumber;
}


int CVoice::GetItemText(CString &itext,int item)
{
	if(!IsReady()) return 0;
	if(item>=GetItemCount()) return 0;
	if(!m_pItems) return 0;
	itext=m_pItems[item].text;
	return 1;
}

int CVoice::GetItemWave(CString &iwave,int item)
{
	if(!IsReady()) return 0;
	if(item>=GetItemCount()) return 0;
	if(!m_pItems) return 0;
	iwave=m_pItems[item].wave;
	if(iwave.IsEmpty()) return 0;
	return 1;
}

int CVoice::AddItem(CString &itext)
{
	if(!IsReady()) return 0;
	if(!StopSync()) return 0;
	if(!m_pItems) return 0;
	CString tstr,wname,pho=itext;
	char c;
	int i,plen,in;
	plen=pho.GetLength();
	if(!plen) {
		::MessageBox(0,"The phoneme is empty.","Error!",MB_OK|MB_TOPMOST);
		return 0;
	}
	if(plen>PHONEME_MAXCHARS){
		::MessageBox(0,"The phoneme can contain up to 7 characters.","Error!",MB_OK|MB_TOPMOST);
		return 0;
	}
	pho.MakeLower();
	in=m_dsVoice.dwNumber;
	for(i=0;i<in;i++){
		if(pho==m_pItems[i].text){
		::MessageBox(0,"The voice already contain such phoneme.","Error!",MB_OK|MB_TOPMOST);
		return 0;
		}
	}
	wname.Empty();
	for(i=0;i<plen;i++){
		c=pho.GetAt(i);
		if((c<'�')&&(c>'�')&&(c!='_')&&(c!='^')&&(c!='~')){
			::MessageBox(0,"The phoneme contains wrong character.","Error!",MB_OK|MB_TOPMOST);
			return 0;
		}
		else{
			if((c>='�')&&(c<='�')){
				wname=wname+eq[c-'�'];
			}
			else{
				wname=wname+c;
			}
		}
	}
	if(wname.GetLength()>23) return 0;
	if((m_dsVoice.dwNumber+1)<VOICE_MAXITEMS){
		strcpy(m_pItems[m_dsVoice.dwNumber].text,LPCTSTR(pho));
		strcpy(m_pItems[m_dsVoice.dwNumber].wave,LPCTSTR(wname));
		m_dsVoice.dwNumber=m_dsVoice.dwNumber+1;
	}
	return 1;
}

int CVoice::SaveVoice()
{
	if(!IsReady()) return 0;
	CFile file;
	int ds=m_dsVoice.dwNumber*sizeof(DS_VITEM);

	if(file.Open(m_vddname, CFile::modeCreate|CFile::modeWrite)){
		file.Write(&m_dsVoice,sizeof(DS_VOICE));
		if(m_pItems&&ds){
		file.Write(m_pItems,ds);
		}
	file.Close();
	}
	else{
	::MessageBox(0,"Can't create voice file.","Error!",MB_OK|MB_TOPMOST);
	return 0;
	}
	return 1;

}
#endif


int CVoice::GetVoiceFileName(CString &vddname)
{
	if(m_vddname.IsEmpty()){
		vddname.Empty();
		return 0;
	}
	vddname=m_vddname;
	return 1;
}
int CVoice::GetVoiceName(CString &vname)
{
	if(m_dsVoice.name[0]==0){
		vname.Empty();
		return 0;
	}
	vname=m_dsVoice.name;
	return 1;
}

int CVoice::GetTextIndex(CString &itext)
{
	if(!IsReady()) return -1;
	if((m_dsVoice.dwNumber<=0)||(m_pItems==0))		return -1;
	for(DWORD i=0;i<m_dsVoice.dwNumber;i++){
		if(m_pItems[i].text==itext) return i;
	}
	return -1;
}

int CVoice::SetText(char *ptext, int textsize)
{
	if(!StopSync()) return 0;
	return m_text.SetText(ptext,textsize);
}

int CVoice::SetString(char *pstring)
{
	if(!StopSync()) return 0;
	return m_text.SetString(pstring);
}

int CVoice::SetString(CString &string)
{
	if(!StopSync()) return 0;
	return m_text.SetString(string);
}

int CVoice::Start()
{
	if(!IsReady()) return 0;
	if(!StopSync()) return 0;
	m_bStarted=1;
	m_bStop=0;
	PostThreadMessage(WM_VOICE_PLAY,0,0);
	return 1;
}

int CVoice::Stop()
{
	m_bStop=1;
	if(m_hWaveOut) waveOutReset(m_hWaveOut);
	return 1;
}

int CVoice::StopSync()
{
	m_bStop=1;
	if(m_hWaveOut) waveOutReset(m_hWaveOut);
	int i=0;
	while((i<500)&&((m_hWaveOut)||(m_bStarted))){
		i=i+1;
		Sleep(2);
	}
	if(!((m_hWaveOut)||(m_bStarted))) return 1;
	return 0;
}

int CVoice::IsReady()
{
	if(m_vddname.IsEmpty())									return 0;
	if(m_dsVoice.dwDT!=VOICE_DT)							return 0;
	if(m_dsVoice.dwNumber>VOICE_MAXITEMS)					return 0;
	if(m_dsVoice.dwNumber<0)								return 0;
	if(m_dsVoice.dwChannels>1)								return 0;
	if((m_dsVoice.dwSPS<11025)||(m_dsVoice.dwSPS>44100))	return 0;
	if((m_dsVoice.dwBPS!=8)&&(m_dsVoice.dwBPS!=16))			return 0;
	if(m_dsVoice.dwType!=1)									return 0;
	if((m_dsVoice.dwNumber>0)&&(m_pItems==0))				return 0;
	
	return 1;
}

void* CVoice::LoadWave(int item, DWORD &samples)
{
	if(!IsReady())							return 0;
	CString wname,vddname=m_vddname;			
	if(!GetItemWave(wname,item))	return 0;
	int bs=vddname.ReverseFind('\\');
	if(bs<0)								return 0;
	vddname=vddname.Left(bs+1);
	if(vddname.IsEmpty())					return 0;
	wname=vddname+wname+".wav";
	CFile file;
	int err=0;
	if(file.Open(wname, CFile::modeRead))
	{
		char szTmp[10];
		WAVEFORMATEX pcmWaveFormat;
		ZeroMemory(szTmp, 10 * sizeof(char));
		file.Read(szTmp, 4 * sizeof(char)) ;
		if (strncmp(szTmp, _T("RIFF"), 4) != 0) {
			goto errex;
		}
		DWORD dwFileSize/* = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36*/ ;
		file.Read(&dwFileSize, sizeof(dwFileSize)) ;
		ZeroMemory(szTmp, 10 * sizeof(char));
		file.Read(szTmp, 8 * sizeof(char)) ;
		if (strncmp(szTmp, _T("WAVEfmt "), 8) != 0) {
			goto errex;
		}
		DWORD dwFmtSize /*= 16L*/;
		file.Read(&dwFmtSize, sizeof(dwFmtSize)) ;
		file.Read(&pcmWaveFormat, dwFmtSize) ;//new
		ZeroMemory(szTmp, 10 * sizeof(char));
		file.Read(szTmp, 4 * sizeof(char)) ;
		if (strncmp(szTmp, _T("data"), 4) != 0) {
			goto errex;
		}
		DWORD dwNum;
		file.Read(&dwNum, sizeof(dwNum)) ;
		
		if(dwNum>500000)									goto errex;		
		if(dwNum==0)										goto errex;		
		if(pcmWaveFormat.nChannels!=m_dsVoice.dwChannels)	goto errex;
		if(pcmWaveFormat.nSamplesPerSec!=m_dsVoice.dwSPS)	goto errex;
		if(pcmWaveFormat.wBitsPerSample!=m_dsVoice.dwBPS)	goto errex;
		if(pcmWaveFormat.nBlockAlign!=((m_dsVoice.dwBPS>>3)*m_dsVoice.dwChannels))	goto errex;

		void *buf;
		buf=malloc(dwNum);
		if(!buf)	goto errex;
		file.Read(buf, dwNum) ;
		file.Close();
		samples=dwNum/pcmWaveFormat.nBlockAlign;
		return buf;
	}
	return 0;
errex:
		file.Close();
	return 0;
}

int CVoice::WaveOut(void *wdata, DWORD size)
{
	WAVEFORMATEX wf;
	MMRESULT res;
	wf.cbSize=sizeof(WAVEFORMATEX);
	wf.wFormatTag = WAVE_FORMAT_PCM;
	wf.nChannels = (WORD)m_dsVoice.dwChannels;
	wf.nSamplesPerSec = m_dsVoice.dwSPS;
	wf.nAvgBytesPerSec = m_dsVoice.dwSPS * m_dsVoice.dwChannels * m_dsVoice.dwBPS / 8;
	wf.nBlockAlign = (WORD)(m_dsVoice.dwChannels * m_dsVoice.dwBPS / 8);
	wf.wBitsPerSample = (WORD)m_dsVoice.dwBPS;
	res=waveOutOpen(&m_hWaveOut, m_WaveDevice, &wf, m_nThreadID, NULL,CALLBACK_THREAD);
	if(res != MMSYSERR_NOERROR)	return 0;

	ZeroMemory(&m_tagWaveHdr,sizeof(WAVEHDR));
	m_tagWaveHdr.lpData = (char*)wdata;
	m_tagWaveHdr.dwBufferLength = size;// * (m_dsVoice.dwChannels * m_dsVoice.dwBPS / 8);
	m_tagWaveHdr.dwFlags = 0;
	m_tagWaveHdr.dwUser = 0;
	//m_tagWaveHdr.dwLoops =0;
	res=waveOutPrepareHeader(m_hWaveOut, &m_tagWaveHdr, sizeof(WAVEHDR)); 
	if(res != MMSYSERR_NOERROR)	return 0;

	res=waveOutWrite(m_hWaveOut, &m_tagWaveHdr, sizeof(WAVEHDR));
	if(res != MMSYSERR_NOERROR){	
		waveOutUnprepareHeader( m_hWaveOut, &m_tagWaveHdr, sizeof(WAVEHDR) );
		ZeroMemory(&m_tagWaveHdr,sizeof(WAVEHDR));
		return 0;
	}
	return 1;
}

int CVoice::RemoveItem(DWORD item)
{
	if(!IsReady()) return 0;
	if(!StopSync()) return 0;
	DWORD i;
	if(item>=m_dsVoice.dwNumber) return 0;
	if(m_dsVoice.dwNumber==0) return 0;
	for(i=item;(i+1)<m_dsVoice.dwNumber;i++) m_pItems[i]=m_pItems[i+1];
	m_dsVoice.dwNumber=m_dsVoice.dwNumber-1;
	return 1;
}


int CVoice::SentenceBack(int count)
{
	if(!StopSync()) return 0;
	return m_text.SentenceBack(count);
}

int CVoice::SentenceForth(int count)
{
	if(!StopSync()) return 0;
	return m_text.SentenceForth(count);
}
int CVoice::WordBack(int count)
{
	if(!StopSync()) return 0;
	return m_text.WordBack(count);
}

int CVoice::WordForth(int count)
{
	if(!StopSync()) return 0;
	return m_text.WordForth(count);
}

DWORD CVoice::GetBPS()
{
	return m_dsVoice.dwBPS;
}

DWORD CVoice::GetSPS()
{
	return m_dsVoice.dwSPS;
}

DWORD CVoice::GetPosition()
{
	return m_text.GetPosition();
}

int CVoice::SetPosition(DWORD pos)
{
	return m_text.SetPosition(pos);
}

int CVoice::SetOverlap(DWORD size)
{
	if(!StopSync()) return 0;
	if(size>10000)	m_dwOverlap=10000;
	else			m_dwOverlap=size;
	return m_dwOverlap;
}

int CVoice::SetMaxCh(DWORD maxch)
{
	if(!StopSync()) return 0;
	m_iMaxChars=maxch;
	if(m_iMaxChars>7)		m_iMaxChars=7;
	if(m_iMaxChars<1)		m_iMaxChars=1;
	return m_iMaxChars;

}
