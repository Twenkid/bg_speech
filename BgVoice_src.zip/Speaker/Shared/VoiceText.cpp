// VoiceText.cpp: implementation of the CVoiceText class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VoiceText.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

char *snum[10]={"����","����","���","���","������","���","����","�����","����","�����"};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVoiceText::CVoiceText()
{
	m_pText=NULL;
	m_iTextSize=0;
	m_iTextPtr=0;
	m_pTempText=NULL;
	m_iTempTextSize=0;
	m_iTempTextPtr=0;
}

CVoiceText::~CVoiceText()
{
	Empty();
}

void CVoiceText::Empty()
{
	FreeTempText();
	FreeText();
}

void CVoiceText::FreeText()
{
	if(m_pText) free(m_pText);
	m_pText=0;
	m_iTextSize=0;
	m_iTextPtr=0;
}	

void CVoiceText::FreeTempText()
{
	if(m_pTempText) free(m_pTempText);
	m_pTempText=0;
	m_iTempTextSize=0;
	m_iTempTextPtr=0;
}	

int CVoiceText::SetText(char *ptext, int textsize)
{
int ts;
	FreeText();
	if(!ptext)		return 0;
	if(!textsize)	return 0;
	for(ts=0;ts<textsize;ts++){
		if(ptext[ts]==0/*||ptext[ts]==EOF*/) break;
	}
	if(ts<=0)		return 0;
	m_pText=(char*)malloc(ts+1);
	if(!m_pText)	return 0;
	MoveMemory(m_pText,ptext,ts);
	m_pText[ts]=0;
	m_iTextSize=ts;
	return 1;
}

int CVoiceText::SetString(char *pstring)
{
int ts;
	FreeText();
	if(!pstring)		return 0;
	ts=strlen(pstring);
	if(ts<=0)			return 0;
	m_pText=(char*)malloc(ts+1);
	if(!m_pText)		return 0;
	MoveMemory(m_pText,pstring,ts);
	m_pText[ts]=0;
	m_iTextSize=ts;
	return 1;
}

int CVoiceText::SetString(CString &string)
{
int ts;
	FreeText();
	if(string.IsEmpty())	return 0;
	ts=string.GetLength();
	if(ts<=0)			return 0;
	m_pText=(char*)malloc(ts+1);
	if(!m_pText)		return 0;
	MoveMemory(m_pText,LPCTSTR(string),ts);
	m_pText[ts]=0;
	m_iTextSize=ts;
	return 1;
}

int CVoiceText::GetWord(CString &strWord)
{
	strWord.Empty();
	if(GetTempWord(strWord)){
		if(!strWord.IsEmpty()){
			return 1;
		}
	}
	if(!m_pText)					return 0;
	if(m_iTextSize<=0)				return 0;
	if(m_iTextPtr<0)				return 0;
	if((m_iTextPtr+1)>=m_iTextSize)	return 0;

	char c=m_pText[m_iTextPtr];
	while(((c==' ')||CanIgnore(c))){
		if((m_iTextPtr+1)>=m_iTextSize) break;
		m_iTextPtr=m_iTextPtr+1;
		c=m_pText[m_iTextPtr];
	}
	if((m_iTextPtr)>=m_iTextSize)	return 0;
	
	CString tstr;
	tstr.Empty();
	while((IsCyrillic(c))){
		tstr=tstr+c;
		if((m_iTextPtr+1)>=m_iTextSize) break;
		m_iTextPtr=m_iTextPtr+1;
		c=m_pText[m_iTextPtr];
	}
	if(!tstr.IsEmpty()){
		tstr.MakeLower();
		strWord=tstr;
		return 1;
	}
	if((IsNumber(c))){
		int inum=(int)(c-'0');
		strWord=snum[inum];
		m_iTextPtr=m_iTextPtr+1;
		return 1;
	}
/*
	while((IsNumber(c))){
		if((m_iTextPtr+1)>=m_iTextSize) break;
		tstr=tstr+c;
		m_iTextPtr=m_iTextPtr+1;
		c=m_pText[m_iTextPtr];
	}
	if(!tstr.IsEmpty()){
		strWord="�����";
		return 1;
	}
*/
	if((c=='.')||(c=='!')||(c=='?')||(c==':')){
		m_iTextPtr=m_iTextPtr+1;
		return 1;
	}
	if((c==',')||(c=='-')||(c=='"')){
		m_iTextPtr=m_iTextPtr+1;
		return 1;
	}
		m_iTextPtr=m_iTextPtr+1;
		//strWord="������";
		return 1;

	return 0;
}

int CVoiceText::GetTempWord(CString &strWord)
{
	strWord.Empty();
	return 0;
}

int CVoiceText::CanIgnore(char c)
{
	if((c<' ')&&(c>=0)) return 1;
	if((c>=0x80)&&(c<=0xbf)) return 1;
	return 0;
}

int CVoiceText::IsNumber(char c)
{
	if((c>='0')&&(c<='9')) return 1;
	return 0;
}

int CVoiceText::IsCyrillic(char c)
{
	if((c>='�')&&(c<='�')) return 1;
	if((c>='�')&&(c<='�')) return 1;
	return 0;

}


int CVoiceText::SentenceBack(int count)
{
	if(!m_pText)					return 0;
	if(m_iTextSize<=0)				return 0;
	if(m_iTextPtr<1)				return 0;
	if((m_iTextPtr+1)>m_iTextSize)	return 0;

	char c;
	int i,tflag,cnt;
	cnt=count;
	if(count<1) return 0;
	if(count>1000) cnt=1000;
	FreeTempText();
	for(i=0;i<count;i++){
		tflag=0;
		while(m_iTextPtr>0){
			c=m_pText[m_iTextPtr-1];
			if(IsNumber(c)||IsCyrillic(c)) tflag=1;
			if(((c=='.')||(c=='!')||(c=='?')||(c==':'))&&(tflag==1)) break;
			m_iTextPtr=m_iTextPtr-1;
		}
	}
	return 1;
}

int CVoiceText::SentenceForth(int count)
{
	if(!m_pText)					return 0;
	if(m_iTextSize<=0)				return 0;
	if(m_iTextPtr<0)				return 0;
	if((m_iTextPtr+1)>=m_iTextSize)	return 0;

	char c;
	int i,tflag,cnt;
	cnt=count;
	if(count<1) return 0;
	if(count>1000) cnt=1000;
	FreeTempText();
	for(i=0;i<count;i++){
		tflag=0;
		while((m_iTextPtr+1)<m_iTextSize){
			c=m_pText[m_iTextPtr+1];
			if(IsNumber(c)||IsCyrillic(c)) tflag=1;
			if(((c=='.')||(c=='!')||(c=='?')||(c==':'))&&(tflag==1)) break;
			m_iTextPtr=m_iTextPtr+1;
		}
	}
	return 1;
}

int CVoiceText::WordBack(int count)
{
	if(!m_pText)					return 0;
	if(m_iTextSize<=0)				return 0;
	if(m_iTextPtr<1)				return 0;
	if((m_iTextPtr+1)>m_iTextSize)	return 0;

	char c;
	int i,tflag,cnt;
	cnt=count;
	if(count<1) return 0;
	if(count>1000) cnt=1000;
	FreeTempText();
	for(i=0;i<count;i++){
		tflag=0;
		while(m_iTextPtr>0){
			c=m_pText[m_iTextPtr-1];
			if(IsNumber(c)||IsCyrillic(c)){
				tflag=1;
			}
			else{
			if(tflag==1) break;
			}
			m_iTextPtr=m_iTextPtr-1;
		}
	}
	return 1;
}

int CVoiceText::WordForth(int count)
{
	if(!m_pText)					return 0;
	if(m_iTextSize<=0)				return 0;
	if(m_iTextPtr<0)				return 0;
	if((m_iTextPtr+1)>=m_iTextSize)	return 0;

	char c;
	int i,tflag,cnt;
	cnt=count;
	if(count<1) return 0;
	if(count>1000) cnt=1000;
	FreeTempText();
	for(i=0;i<count;i++){
		tflag=0;
		while((m_iTextPtr+1)<m_iTextSize){
			c=m_pText[m_iTextPtr+1];
			if(IsNumber(c)||IsCyrillic(c)){
				tflag=1;
			}
			else{
			if(tflag==1) break;
			}
			m_iTextPtr=m_iTextPtr+1;
		}
	}
	return 1;
}

DWORD CVoiceText::GetPosition()
{
	return m_iTextPtr;
}

int CVoiceText::SetPosition(DWORD pos)
{
	if(!m_pText)			return 0;
	if(m_iTextSize<=0)		return 0;
	if(pos>(DWORD)m_iTextSize)		return 0;
	m_iTextPtr=pos;
	return 1;
}
