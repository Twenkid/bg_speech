// WaveIO.h: interface for the CWaveIO class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAVEIO_H__4E39E681_7449_11D7_9A0D_000000000000__INCLUDED_)
#define AFX_WAVEIO_H__4E39E681_7449_11D7_9A0D_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Wave.h"
#include "WaveDevice.h"
#include "WaveInterface.h"
#include "WaveOut.h"
#include "WaveIn.h"

class CWaveIO  
{
public:
	int SetFormat(int sps,int bps);
	int GetBPS();
	int PlayAll();
	void FreeWave();
	int SaveSelection(CString fname);
	int Load(const char *filename);
	int GetNumSamples();
	void* GetBuffer();
	int GetSelInSample();
	int GetSelOutSample();
	int SetSelInSample(int sample);
	int SetSelOutSample(int sample);
	int Play();
	int StopRecord();
	int Record();
	CWaveIO();
	virtual ~CWaveIO();


protected:
	int CheckFormat();
	CWaveIn		m_WaveIn;
	CWaveOut	m_WaveOut;
	CWaveDevice m_InDevice;
	CWaveDevice m_OutDevice;
	CWave		m_Wave;
	int			m_iSelIn;
	int			m_iSelOut;
	int			m_iSPS;
	int			m_iBPS;
};

#endif // !defined(AFX_WAVEIO_H__4E39E681_7449_11D7_9A0D_000000000000__INCLUDED_)
