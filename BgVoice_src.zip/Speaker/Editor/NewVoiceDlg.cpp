// NewVoiceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "speaker.h"
#include "NewVoiceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewVoiceDlg dialog


CNewVoiceDlg::CNewVoiceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewVoiceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewVoiceDlg)
	m_bps = 1;
	m_sps = 2;
	m_vname = _T("");
	//}}AFX_DATA_INIT
}


void CNewVoiceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewVoiceDlg)
	DDX_CBIndex(pDX, IDC_COMBO_BPS, m_bps);
	DDX_CBIndex(pDX, IDC_COMBO_SPS, m_sps);
	DDX_Text(pDX, IDC_EDIT_VNAME, m_vname);
	DDV_MaxChars(pDX, m_vname, 30);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewVoiceDlg, CDialog)
	//{{AFX_MSG_MAP(CNewVoiceDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewVoiceDlg message handlers
