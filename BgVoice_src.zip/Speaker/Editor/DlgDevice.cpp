// DlgDevice.cpp : implementation file
//

#include "stdafx.h"
#include "Speaker.h"
#include "DlgDevice.h"
#include "WaveInterface.h"	

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDevice dialog


CDlgDevice::CDlgDevice(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDevice::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDevice)
	m_in = 0;
	m_out = 0;
	//}}AFX_DATA_INIT
}


void CDlgDevice::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDevice)
	DDX_Control(pDX, IDC_COMBO_OUT, m_comboOut);
	DDX_Control(pDX, IDC_COMBO_IN, m_comboIn);
	DDX_CBIndex(pDX, IDC_COMBO_IN, m_in);
	DDX_CBIndex(pDX, IDC_COMBO_OUT, m_out);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDevice, CDialog)
	//{{AFX_MSG_MAP(CDlgDevice)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDevice message handlers

BOOL CDlgDevice::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	UINT i = 0;
	for (i = 0; i < CWaveInterface::GetWaveInCount(); i++) {
		if (!CWaveInterface::GetWaveInName(i).IsEmpty())
			m_comboIn.AddString(CWaveInterface::GetWaveInName(i));
	}
	for (i = 0; i < CWaveInterface::GetWaveOutCount(); i++) {
		if (!CWaveInterface::GetWaveOutName(i).IsEmpty())
			m_comboOut.AddString(CWaveInterface::GetWaveOutName(i));
	}
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
