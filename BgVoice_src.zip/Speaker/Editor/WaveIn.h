#if !defined(AFX_WAVEIN_H__75FB34C5_7A90_11D7_9A20_000000000000__INCLUDED_)
#define AFX_WAVEIN_H__75FB34C5_7A90_11D7_9A20_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WaveIn.h : header file
//
#include "Wave.h"
#include "WaveDevice.h"

//////////////////////////////////////////////////////////////////////
#ifdef WAVE_IN_BUFFER_SIZE
#undef WAVE_IN_BUFFER_SIZE
#endif
#define WAVEIN_BUFFER_SIZE 4096

//////////////////////////////////////////////////////////////////////
#ifdef NUMWAVEINHDR
#undef NUMWAVEINHDR
#endif
#define NUMWAVEINHDR 2

/////////////////////////////////////////////////////////////////////////////
// CWaveIn thread

class CWaveIn : public CWinThread
{
	DECLARE_DYNCREATE(CWaveIn)
protected:
//	CWaveIn();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	CString GetError() const;
	DWORD GetPosition();
	bool IsRecording();
	CWave MakeWave();

	bool Close();
	bool Continue();
	bool Open();
	bool Pause();
	bool Record(UINT nTaille = 4096);
	bool Stop();

	void SetDevice(const CWaveDevice& aDevice);
	void SetWaveFormat(WAVEFORMATEX tagFormat);

	CWaveIn();
	CWaveIn(WAVEFORMATEX tagFormat, const CWaveDevice& aDevice);
	virtual	~CWaveIn();



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWaveIn)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWaveIn)
		// NOTE - the ClassWizard will add and remove member functions here.
	afx_msg void On_MM_WIM_DATA(UINT parm1, LONG parm2);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	bool AddNewBuffer(WAVEHDR* pWaveHdr);
	bool AddNewHeader(HWAVEIN hwi);
	void FreeListOfBuffer();
	DWORD GetNumSamples();
	void FreeListOfHeader();
	void InitListOfHeader();
	bool IsError(MMRESULT nResult);
	bool ResetRequired(CWaveIn* pWaveIn);
private:
	bool m_bResetRequired;
	HWAVEIN	m_hWaveIn;
	CPtrList m_listOfBuffer;
	UINT m_nError;
	int	m_nIndexWaveHdr;
	UINT m_nBufferSize;
	WAVEHDR	m_tagWaveHdr[NUMWAVEINHDR];
	CWave m_wave;
	CWaveDevice m_waveDevice;

	DWORD m_ThreadID;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAVEIN_H__75FB34C5_7A90_11D7_9A20_000000000000__INCLUDED_)
