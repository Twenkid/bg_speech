// DlgWEditor.cpp : implementation file
//

#include "stdafx.h"
#include "Speaker.h"
#include "DlgWEditor.h"
#include "DlgDevice.h"
#include "NewVoiceDlg.h"

#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString	basePath;
/////////////////////////////////////////////////////////////////////////////
// CDlgWEditor dialog


CDlgWEditor::CDlgWEditor(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgWEditor::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgWEditor)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT 
	m_dev_in=0;
	m_dev_out=0;
	m_zoom=1;
	m_changed=0;
}


void CDlgWEditor::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgWEditor)
	DDX_Control(pDX, IDC_CHECK_OVER, m_btnOver);
	DDX_Control(pDX, IDC_COMBO_MAXCH, m_ComboMaxCh);
	DDX_Control(pDX, IDC_EDIT_SAY2, m_editSay2);
	DDX_Control(pDX, IDC_EDIT_SAY1, m_editSay1);
	DDX_Control(pDX, IDC_STATIC_VOICE_NAME, m_staticVoiceName);
	DDX_Control(pDX, IDC_STATIC_WAVEFILE, m_staticWaveFile);
	DDX_Control(pDX, IDC_EDIT_PHONEME, m_EditPhoneme);
	DDX_Control(pDX, IDC_COMBO_ITEM, m_ComboItems);
	DDX_Control(pDX, IDC_CHECK_REC, m_btnRecord);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgWEditor, CDialog)
	//{{AFX_MSG_MAP(CDlgWEditor)
	ON_BN_CLICKED(IDC_BUTTON_PREF, OnButtonPref)
	ON_BN_CLICKED(IDC_CHECK_REC, OnCheckRec)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_ZOOMIN, OnButtonZoomin)
	ON_BN_CLICKED(IDC_BUTTON_ZOOMOUT, OnButtonZoomout)
	ON_BN_CLICKED(IDC_BUTTON_LOAD, OnButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_NEW, OnButtonNew)
	ON_BN_CLICKED(IDC_BUTTON_ADD_PHONEME, OnButtonAddPhoneme)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE_WAVE, OnButtonUpdateWave)
	ON_CBN_SELCHANGE(IDC_COMBO_ITEM, OnSelchangeComboItem)
	ON_BN_CLICKED(IDC_BUTTON_SAY1, OnButtonSay1)
	ON_BN_CLICKED(IDC_BUTTON_SAY2, OnButtonSay2)
	ON_BN_CLICKED(IDOK_N, OnOk_N)
	ON_BN_CLICKED(IDC_BUTTON_PLAYALL, OnButtonPlayAll)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_SBACK, OnButtonSback)
	ON_BN_CLICKED(IDC_BUTTON_SFORTH, OnButtonSforth)
	ON_BN_CLICKED(IDC_BUTTON_WBACK, OnButtonWback)
	ON_BN_CLICKED(IDC_BUTTON_WFORTH, OnButtonWforth)
	ON_BN_CLICKED(IDC_CHECK_OVER, OnCheckOver)
	ON_CBN_SELCHANGE(IDC_COMBO_MAXCH, OnSelchangeComboMaxch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgWEditor message handlers

void CDlgWEditor::OnButtonPref() 
{
	// TODO: Add your control notification handler code here
	CDlgDevice dlg;
	dlg.m_in=m_dev_in;
	dlg.m_out=m_dev_out;
	dlg.DoModal();
	m_dev_in=dlg.m_in;
	m_dev_out=dlg.m_out;
}

void CDlgWEditor::OnCheckRec() 
{
	// TODO: Add your control notification handler code here
	int state=m_btnRecord.GetCheck()&1;
	if(state){
		m_btnRecord.SetWindowText("Stop Record");
		SetTimer(1,4000,0);
		m_WaveIO.Record();
		}
	else{
		m_btnRecord.SetWindowText("Record");
		m_WaveIO.StopRecord();
		m_OScopeCtrl.Zoom(1.0);
		m_zoom=1;
		//m_OScopeCtrl.DrawWave();
		//m_OScopeCtrl.Invalidate();
	}
}

void CDlgWEditor::OnButtonPlay() 
{
	// TODO: Add your control notification handler code here
	m_WaveIO.Play();
}

BOOL CDlgWEditor::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CRect rect;
	GetDlgItem(IDC_OSCOPE)->GetWindowRect(rect) ;
	ScreenToClient(rect) ;

	// create the control
	m_OScopeCtrl.Create(WS_VISIBLE | WS_CHILD, rect, this) ; 

	// customize the control
	m_OScopeCtrl.SetRange(-1.0, 1.0, 1) ;
	m_OScopeCtrl.SetYUnits("Signal") ;
	m_OScopeCtrl.SetXUnits("Seconds") ;
	m_OScopeCtrl.SetBackgroundColor(RGB(0, 0, 64)) ;
	m_OScopeCtrl.SetGridColor(RGB(192, 192, 255)) ;
	m_OScopeCtrl.SetPlotColor(RGB(255, 255, 255)) ;
	m_OScopeCtrl.SetWave(&m_WaveIO);

	m_editSay1.SetWindowText("����� 1");
	m_editSay2.SetWindowText("����� 2");
	m_ComboMaxCh.SetCurSel(6);
	m_btnOver.SetCheck(1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgWEditor::OnButtonZoomin() 
{
	// TODO: Add your control notification handler code here
	if(m_zoom>=8) return;
	m_zoom=m_zoom*2;
	m_OScopeCtrl.Zoom(m_zoom);
}

void CDlgWEditor::OnButtonZoomout() 
{
	// TODO: Add your control notification handler code here
	if(m_zoom<=1) return;
	m_zoom=m_zoom/2;
	m_OScopeCtrl.Zoom(m_zoom);
	//m_OScopeCtrl.Invalidate();
}

void CDlgWEditor::OnButtonLoad() 
{
	// TODO: Add your control notification handler code here
	CFileDialog LoadDialog(TRUE ,"vdd",NULL,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY,
							"Voice Data (*.vdd)|*.vdd|",this);


	CString dd;
	if(!basePath.IsEmpty()){
		dd=basePath;
		dd=dd+"\\Voices\\";
		LoadDialog.m_ofn.lpstrInitialDir=LPCTSTR(dd);
	}
	int result=LoadDialog.DoModal();
	if(result==IDOK){
	CString fname;
	fname=LoadDialog.GetPathName();
		if(!fname.IsEmpty()){
			if(LoadVoice(fname)){
				m_WaveIO.SetFormat(m_voice.GetSPS(),m_voice.GetBPS());
				UpdateUI();
				m_changed=0;
			}
		}
	}
}

void CDlgWEditor::OnButtonNew() 
{
	// TODO: Add your control notification handler code here
	CNewVoiceDlg dlg;
	int sps[4]={11025,22050,44100,0};
	int copy=0;
	short keys=0;
	keys=GetKeyState(VK_MENU);
	if(!(keys>=0)) copy=1;
	int result=dlg.DoModal();
	if(result==IDOK){
		if(!dlg.m_vname.IsEmpty()){
			CString dd;
			if(!basePath.IsEmpty()){
				dd=basePath;
				dd=dd+"\\Voices";
				if(m_voice.MakeNew(dd,dlg.m_vname,1,sps[dlg.m_sps&3],dlg.m_bps?16:8,1,copy)){
					m_WaveIO.SetFormat(sps[dlg.m_sps&3],dlg.m_bps?16:8);
					UpdateUI();
				}
				m_changed=0;
			}
		}
	}
}

void CDlgWEditor::UpdateUI()
{
	m_ComboItems.ResetContent();
	int i,count;
	CString item;
	count=m_voice.GetItemCount();
	for(i=0;i<count;i++){
	m_voice.GetItemText(item,i);
	m_ComboItems.AddString(item);
	}
	m_ComboItems.SetCurSel(0);
	CString vname,sinfo;
	if(m_voice.GetVoiceName(vname)){
		vname=" "+vname;
		sinfo.Format(" %d kHz %d bit",m_voice.GetSPS(),m_voice.GetBPS());
		vname=vname+sinfo;
		m_staticVoiceName.SetWindowText(vname);
	}
	else{
		m_staticVoiceName.SetWindowText("None");
	}
	OnSelchangeComboItem();
}

void CDlgWEditor::OnButtonAddPhoneme() 
{
	// TODO: Add your control notification handler code here
	short keys=0;
	keys=GetKeyState(VK_MENU);
	if(!(keys>=0)){	
		int item;
		item=GetSelectedItem();
		if(item==CB_ERR)						return;
		if(m_voice.RemoveItem(item)){
		m_voice.SaveVoice();
		}
		UpdateUI();
	}
	else{
		CString pho;
		int item;
		m_EditPhoneme.GetWindowText(pho);
		if(m_voice.AddItem(pho)){
			m_changed=1;
			pho.MakeLower();
			item=m_ComboItems.AddString(pho);
			m_ComboItems.SetCurSel(item);
			OnSelchangeComboItem();
			m_voice.SaveVoice();
		}
	}
}

int CDlgWEditor::LoadVoice(CString &vname)
{
	return m_voice.LoadVoice(vname);
}

void CDlgWEditor::OnButtonSave() 
{
	// TODO: Add your control notification handler code here
	m_voice.SaveVoice();
}

void CDlgWEditor::OnButtonUpdateWave() 
{
	// TODO: Add your control notification handler code here
	int item;
	item=GetSelectedItem();
	if(item==CB_ERR)						return;
	CString wname,vddname;

	if(!m_voice.GetItemWave(wname,item))	return;
	if(wname.IsEmpty())						return;
	if(!m_voice.GetVoiceFileName(vddname))	return;
				
	int bs=vddname.ReverseFind('\\');
	if(bs<0)								return;
	vddname=vddname.Left(bs+1);
	if(vddname.IsEmpty())					return;
	wname=vddname+wname+".wav";
				
	if(m_WaveIO.SaveSelection(wname)){
	m_voice.GetItemWave(wname,item);
	m_staticWaveFile.SetWindowText(" Wave File: "+wname+".wav");
	}
}

int CDlgWEditor::LoadWave(CString &wname)
{
	return 0;
}

void CDlgWEditor::OnSelchangeComboItem() 
{
	// TODO: Add your control notification handler code here
	m_staticWaveFile.SetWindowText(" Wave File: None");
	m_WaveIO.FreeWave();
	m_OScopeCtrl.Zoom(1.0);

	int item;
	item=GetSelectedItem();
	if(item==CB_ERR)						return;
	CString wname,vddname;

	if(!m_voice.GetItemWave(wname,item))	return;
	if(wname.IsEmpty())						return;
	if(!m_voice.GetVoiceFileName(vddname))	return;
				
	int bs=vddname.ReverseFind('\\');
	if(bs<0)								return;
	vddname=vddname.Left(bs+1);
	if(vddname.IsEmpty())					return;
	wname=vddname+wname+".wav";
	CFileFind ff; 
	int found;
	found=ff.FindFile(wname);
	if(found){
		m_WaveIO.Load(LPCTSTR(wname));
		if(m_WaveIO.GetNumSamples()){
			wname.ReverseFind('\\');
			if(bs<0)	return;	
			bs++;
			wname=" Wave File: "+wname.Right(wname.GetLength()-bs);
			m_staticWaveFile.SetWindowText(wname);
			m_OScopeCtrl.Zoom(1.0);
		}
	}
}

int CDlgWEditor::GetSelectedItem()
{
	int item;
	item=m_ComboItems.GetCurSel();
	if(item==CB_ERR)						return CB_ERR;
	CString iname;
	m_ComboItems.GetLBText(item,iname);
	if(iname.IsEmpty())						return CB_ERR;
	if((item=m_voice.GetTextIndex(iname))>=0)	return item;
	return CB_ERR;
}

void CDlgWEditor::OnButtonSay1() 
{
	// TODO: Add your control notification handler code here
	CString say;
	m_editSay1.GetWindowText(say);
	if(!say.IsEmpty()){
		m_voice.SetString(say);
		m_voice.Start();
	}
}

void CDlgWEditor::OnButtonSay2() 
{
	// TODO: Add your control notification handler code here
	CString say;
	m_editSay2.GetWindowText(say);
	if(!say.IsEmpty()){
		m_voice.SetString(say);
		m_voice.Start();
	}
	
}
void CDlgWEditor::OnOK() 
{
	// TODO: Add extra validation here
	
}

void CDlgWEditor::OnOk_N() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CDlgWEditor::OnButtonPlayAll() 
{
	// TODO: Add your control notification handler code here
	m_WaveIO.PlayAll();
}

void CDlgWEditor::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	int state=m_btnRecord.GetCheck()&1;
	if(state){
		KillTimer(1);
		m_WaveIO.StopRecord();
		m_OScopeCtrl.Zoom(1.0);
		m_zoom=1;
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CDlgWEditor::OnButtonStart() 
{
	m_voice.Start();
}

void CDlgWEditor::OnButtonStop() 
{
	m_voice.Stop();
}

void CDlgWEditor::OnButtonSback() 
{
	// TODO: Add your control notification handler code here
	m_voice.SentenceBack(2);
	m_voice.Start();
}

void CDlgWEditor::OnButtonSforth() 
{
	m_voice.SentenceForth(1);
	m_voice.Start();
}

void CDlgWEditor::OnButtonWback() 
{
	m_voice.WordBack(1);
	m_voice.Start();
}

void CDlgWEditor::OnButtonWforth() 
{
	m_voice.WordForth(1);
	m_voice.Start();
}

void CDlgWEditor::OnCheckOver() 
{
	DWORD chs=m_btnOver.GetCheck();
	m_voice.Stop();
	if(chs&1)
	m_voice.SetOverlap(500);
	else
	m_voice.SetOverlap(0);
	m_voice.Start();
}

void CDlgWEditor::OnSelchangeComboMaxch() 
{
	DWORD sel=m_ComboMaxCh.GetCurSel();
	m_voice.Stop();
	m_voice.SetMaxCh(sel+1);
	m_voice.Start();
}
