#if !defined(AFX_WAVEOUT_H__75FB34C6_7A90_11D7_9A20_000000000000__INCLUDED_)
#define AFX_WAVEOUT_H__75FB34C6_7A90_11D7_9A20_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WaveOut.h : header file
//
#include "Wave.h"
#include "WaveDevice.h"
#include <afxmt.h>

//////////////////////////////////////////////////////////////////////
#ifdef WAVE_OUT_BUFFER_SIZE
#undef WAVE_OUT_BUFFER_SIZE
#endif
#define WAVEOUT_BUFFER_SIZE 4096

//////////////////////////////////////////////////////////////////////
#ifdef NUMWAVEOUTHDR
#undef NUMWAVEOUTHDR
#endif
#define NUMWAVEOUTHDR 3

//////////////////////////////////////////////////////////////////////
#ifdef INFINITE_LOOP
#undef INFINITE_LOOP
#endif
#define INFINITE_LOOP INT_MAX

/////////////////////////////////////////////////////////////////////////////
// CWaveOut thread

class CWaveOut : public CWinThread
{
	DECLARE_DYNCREATE(CWaveOut)
protected:
//	CWaveOut();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	CString GetError() const;
	DWORD GetPosition();
	bool IsPlaying();
	
	bool Close();
	bool Continue();
	bool FullPlay(int nLoop = -1, DWORD dwStart = -1, DWORD dwEnd = -1);
	bool Open();
	bool Pause();
	bool Play(DWORD dwStart = -1, DWORD dwEnd = -1);
	bool Stop();

	void ModifyWaveOutBufferLength(DWORD dwLength);
	void SetDevice(const CWaveDevice& aDevice);
	void SetWave(const CWave& aWave);

	CWaveOut();
	CWaveOut(const CWave& aWave, const CWaveDevice& aDevice);
	virtual ~CWaveOut();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWaveOut)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
//	virtual ~CWaveOut();

	// Generated message map functions
	//{{AFX_MSG(CWaveOut)
		// NOTE - the ClassWizard will add and remove member functions here.
		afx_msg void On_MM_WOM_DONE(UINT parm1, LONG parm2);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	bool AddFullHeader(HWAVEOUT hwo, int nLoop);
	bool AddNewHeader(HWAVEOUT hwo);
	DWORD GetBufferLength();
	bool IsError(MMRESULT nResult);
	bool ResetRequired(CWaveOut* pWaveOut);
private:
	DWORD m_dwEndPos;
	DWORD m_dwStartPos;
	DWORD m_dwWaveOutBufferLength;
	HWAVEOUT m_hWaveOut;
	UINT m_nError;
	int m_nIndexWaveHdr;
	WAVEHDR m_tagWaveHdr[NUMWAVEOUTHDR];
	CWave m_wave;
	CWaveDevice m_waveDevice;

	DWORD m_ThreadID;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAVEOUT_H__75FB34C6_7A90_11D7_9A20_000000000000__INCLUDED_)
