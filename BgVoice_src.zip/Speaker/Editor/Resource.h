//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Speaker.rc
//
#define IDD_SPEAKER_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_WEDITOR              130
#define IDD_DIALOG_DEVICE               131
#define IDD_DIALOG_NEW                  133
#define IDC_COMBO_IN                    1000
#define IDC_COMBO_OUT                   1001
#define IDC_BUTTON_PREF                 1001
#define IDC_CHECK_REC                   1002
#define IDC_BUTTON_PLAY                 1003
#define IDC_OSCOPE                      1004
#define IDC_BUTTON_ZOOMIN               1005
#define IDC_BUTTON_ZOOMOUT              1006
#define IDC_COMBO_ITEM                  1007
#define IDC_BUTTON_NEW                  1008
#define IDC_BUTTON_LOAD                 1009
#define IDC_BUTTON_PLAYALL              1011
#define IDC_EDIT_VNAME                  1012
#define IDC_COMBO_SPS                   1013
#define IDC_COMBO_BPS                   1014
#define IDC_EDIT_PHONEME                1015
#define IDC_BUTTON_ADD_PHONEME          1016
#define IDC_BUTTON_SAVE                 1017
#define IDC_BUTTON_UPDATE_WAVE          1018
#define IDC_STATIC_WAVEFILE             1019
#define IDC_STATIC_VOICE_NAME           1020
#define IDC_BUTTON_SAY1                 1021
#define IDC_EDIT_SAY1                   1022
#define IDC_BUTTON_SAY2                 1023
#define IDC_EDIT_SAY2                   1024
#define IDC_BUTTON1                     1025
#define IDC_BUTTON_START                1025
#define IDOK_N                          1026
#define IDC_BUTTON_STOP                 1027
#define IDC_BUTTON_WBACK                1028
#define IDC_BUTTON_WFORTH               1029
#define IDC_BUTTON_SBACK                1030
#define IDC_BUTTON_SFORTH               1031
#define IDC_COMBO_MAXCH                 1032
#define IDC_CHECK_OVER                  1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
