// WaveIO.cpp: implementation of the CWaveIO class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Speaker.h"
#include "WaveIO.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWaveIO::CWaveIO()
{
	m_iSelIn=0;
	m_iSelOut=0;
	m_iSPS=0;
	m_iBPS=0;

}

CWaveIO::~CWaveIO()
{

}

int CWaveIO::Record()
{
	if(!CheckFormat()) return 0;
	if ( m_WaveOut.IsPlaying() ) {
		if ( !m_WaveOut.Close() ) {
			AfxMessageBox( m_WaveOut.GetError() );
			return 0;
		}
	}
	m_Wave.BuildFormat(1, m_iSPS, m_iBPS);
	if ( !m_InDevice.IsInputFormat(m_Wave) ) {
		AfxMessageBox("Format not supported");
		return 0;
	}
	m_WaveIn.SetWaveFormat( m_Wave.GetFormat() );
	m_WaveIn.SetDevice(m_InDevice);
	if ( !m_WaveIn.Open() ) {
		AfxMessageBox( m_WaveIn.GetError() );
		return 0;
	}
	if ( !m_WaveIn.Record() ) {
		AfxMessageBox( m_WaveIn.GetError() );
		return 0;
	}
	return 1;
}

int CWaveIO::StopRecord()
{
	if(!CheckFormat()) return 0;
	if ( !m_WaveIn.Close() ) {
		AfxMessageBox( m_WaveIn.GetError() );
		return 0;
	}
	m_Wave = m_WaveIn.MakeWave();
	SetSelInSample(0);
	SetSelOutSample(m_Wave.GetNumSamples());
	return 1;
}

int CWaveIO::Play()
{
		if ( m_WaveOut.IsPlaying() ) {
			if ( !m_WaveOut.Close() ) {
				AfxMessageBox( m_WaveOut.GetError() );
				return 0;
			}
		}
		if ( !m_OutDevice.IsOutputFormat(m_Wave) ) {
			AfxMessageBox("Format not supported");
			return 0;
		}
		m_WaveOut.SetWave(m_Wave);
		m_WaveOut.SetDevice(m_OutDevice);
		if ( !m_WaveOut.Open() ) {
			AfxMessageBox( m_WaveOut.GetError() );
			return 0;
		}
		if ( !m_WaveOut.Play(m_iSelIn,m_iSelOut) ) {
			AfxMessageBox( m_WaveOut.GetError() );
			return 0;
		}
	return 1;
}

int CWaveIO::GetSelInSample()
{
	if(m_iSelIn>=(int)(m_Wave.GetNumSamples()-1))	m_iSelIn=(int)m_Wave.GetNumSamples()-2;
	if(m_iSelIn>=m_iSelOut)						m_iSelIn=m_iSelOut-1;
	if(m_iSelIn<0)								m_iSelIn=0;
	return m_iSelIn;
}
int CWaveIO::GetSelOutSample()
{
	if(m_iSelIn>=((int)m_Wave.GetNumSamples()-1))	m_iSelIn=(int)m_Wave.GetNumSamples()-2;
	if(m_iSelIn>=m_iSelOut)						m_iSelIn=m_iSelOut-1;
	if(m_iSelIn<0)								m_iSelIn=0;
	if(m_iSelOut<=m_iSelIn)						m_iSelOut=m_iSelIn+1;
	if(m_iSelOut>=((int)m_Wave.GetNumSamples()-1))	m_iSelOut=(int)m_Wave.GetNumSamples()-1;
	if(m_iSelOut<=0)							m_iSelOut=0;
	return m_iSelOut;
}
int CWaveIO::SetSelInSample(int sample)
{
	m_iSelIn=sample;
	if(m_iSelIn>=((int)m_Wave.GetNumSamples()-1))	m_iSelIn=(int)m_Wave.GetNumSamples()-2;
	if(m_iSelIn>=m_iSelOut)						m_iSelIn=m_iSelOut-1;
	if(m_iSelIn<0)								m_iSelIn=0;
	return m_iSelIn;
}
int CWaveIO::SetSelOutSample(int sample)
{
	if(m_iSelIn>=((int)m_Wave.GetNumSamples()-1))	m_iSelIn=(int)m_Wave.GetNumSamples()-2;
	if(m_iSelIn>=m_iSelOut)						m_iSelIn=m_iSelOut-1;
	if(m_iSelIn<0)								m_iSelIn=0;
	m_iSelOut=sample;
	if(m_iSelOut<=m_iSelIn)						m_iSelOut=m_iSelIn+1;
	if(m_iSelOut>=((int)m_Wave.GetNumSamples()-1))	m_iSelOut=m_Wave.GetNumSamples()-1;
	if(m_iSelOut<=0)							m_iSelOut=0;
	return m_iSelOut;
}

void* CWaveIO::GetBuffer()
{
	return m_Wave.GetBuffer();
}

int CWaveIO::GetNumSamples()
{
	return m_Wave.GetNumSamples();
}

int CWaveIO::Load(const char *filename)
{
	m_Wave.Load(filename);
	SetSelInSample(0);
	SetSelOutSample(m_Wave.GetNumSamples());
	return 1;
}

int CWaveIO::SaveSelection(CString fname)
{
	int ns;
	ns=m_Wave.GetNumSamples();
	if(ns){
		if((GetSelInSample()<GetSelOutSample())&&(GetSelOutSample()<ns))
		return m_Wave.SaveSelection(fname,GetSelInSample(),GetSelOutSample());
	}
	return 0;
}

void CWaveIO::FreeWave()
{
	m_iSelIn=0;
	m_iSelOut=0;
	m_Wave.Free();
}

int CWaveIO::PlayAll()
{
		if ( m_WaveOut.IsPlaying() ) {
			if ( !m_WaveOut.Close() ) {
				AfxMessageBox( m_WaveOut.GetError() );
				return 0;
			}
		}
		if ( !m_OutDevice.IsOutputFormat(m_Wave) ) {
			AfxMessageBox("Format not supported");
			return 0;
		}
		m_WaveOut.SetWave(m_Wave);
		m_WaveOut.SetDevice(m_OutDevice);
		if ( !m_WaveOut.Open() ) {
			AfxMessageBox( m_WaveOut.GetError() );
			return 0;
		}
		if ( !m_WaveOut.Play() ) {
			AfxMessageBox( m_WaveOut.GetError() );
			return 0;
		}
	return 1;

}

int CWaveIO::GetBPS()
{
	return m_Wave.GetFormat().wBitsPerSample;
}

int CWaveIO::CheckFormat()
{
	if((m_iSPS!=44100)&&(m_iSPS!=22050)&&(m_iSPS!=11025))	return 0;
	if((m_iBPS!=8)&&(m_iBPS!=16))							return 0;
	return 1;
}

int CWaveIO::SetFormat(int sps, int bps)
{
	if((sps!=44100)&&(sps!=22050)&&(sps!=11025))	return 0;
	if((bps!=8)&&(bps!=16))							return 0;
	m_iBPS=bps;
	m_iSPS=sps;	
	return 1;

}
