// SpeakerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Speaker.h"
#include "SpeakerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpeakerDlg dialog

CSpeakerDlg::CSpeakerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSpeakerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpeakerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
}

void CSpeakerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpeakerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSpeakerDlg, CDialog)
	//{{AFX_MSG_MAP(CSpeakerDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpeakerDlg message handlers

BOOL CSpeakerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSpeakerDlg::OnPaint() 
{
	CDialog::OnPaint();
}

