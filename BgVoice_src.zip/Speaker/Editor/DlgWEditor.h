#if !defined(AFX_DLGWEDITOR_H__003B0E8F_742A_11D7_9A0D_000000000000__INCLUDED_)
#define AFX_DLGWEDITOR_H__003B0E8F_742A_11D7_9A0D_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgWEditor.h : header file
//
#include "WaveIO.h"
#include "..\\Shared\\Voice.h"

#include "OScopeCtrl.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgWEditor dialog

class CDlgWEditor : public CDialog
{
// Construction
public:
	int GetSelectedItem();
	int LoadWave(CString &wname);
	int LoadVoice(CString &vname);
	void UpdateUI();
	CDlgWEditor(CWnd* pParent = NULL);   // standard constructor

// Dialog Data 
	//{{AFX_DATA(CDlgWEditor)
	enum { IDD = IDD_DIALOG_WEDITOR };
	CButton	m_btnOver;
	CComboBox	m_ComboMaxCh;
	CEdit	m_editSay2;
	CEdit	m_editSay1;
	CStatic	m_staticVoiceName;
	CStatic	m_staticWaveFile;
	CEdit	m_EditPhoneme;
	CComboBox	m_ComboItems;
	CButton	m_btnRecord;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgWEditor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int m_changed;
	CVoice m_voice;

	int m_dev_in,m_dev_out;
	CWaveIO	m_WaveIO;
	int m_zoom;
	COScopeCtrl m_OScopeCtrl;
	// Generated message map functions
	//{{AFX_MSG(CDlgWEditor)
	virtual void OnOK();
	afx_msg void OnButtonPref();
	afx_msg void OnCheckRec();
	afx_msg void OnButtonPlay();
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonZoomin();
	afx_msg void OnButtonZoomout();
	afx_msg void OnButtonLoad();
	afx_msg void OnButtonNew();
	afx_msg void OnButtonAddPhoneme();
	afx_msg void OnButtonSave();
	afx_msg void OnButtonUpdateWave();
	afx_msg void OnSelchangeComboItem();
	afx_msg void OnButtonSay1();
	afx_msg void OnButtonSay2();
	afx_msg void OnOk_N();
	afx_msg void OnButtonPlayAll();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonStart();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonSback();
	afx_msg void OnButtonSforth();
	afx_msg void OnButtonWback();
	afx_msg void OnButtonWforth();
	afx_msg void OnCheckOver();
	afx_msg void OnSelchangeComboMaxch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGWEDITOR_H__003B0E8F_742A_11D7_9A0D_000000000000__INCLUDED_)
