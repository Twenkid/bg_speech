// ReaderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Reader.h"
#include "ReaderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReaderDlg dialog

CReaderDlg::CReaderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReaderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReaderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pText=NULL;
	m_dwTextSize=0;
	m_dwTextPos=0;
	m_bHelp=0;
	m_hk1=0;
	m_sTextFile.Empty();
}
CReaderDlg::~CReaderDlg()
{
	FreeText();
}

void CReaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReaderDlg)
	DDX_Control(pDX, IDC_STATIC_TEXT, m_staticText);
	DDX_Control(pDX, IDC_STATIC_FILE, m_staticFile);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CReaderDlg, CDialog)
	//{{AFX_MSG_MAP(CReaderDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_LOAD, OnButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_HOME, OnButtonHome)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_BN_CLICKED(IDC_BUTTON_BACKM, OnButtonBackm)
	ON_BN_CLICKED(IDC_BUTTON_NEXT, OnButtonNext)
	ON_BN_CLICKED(IDC_BUTTON_NEXTM, OnButtonNextm)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReaderDlg message handlers

BOOL CReaderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	if(!m_hk1)
	m_hk1=RegisterHotKey( m_hWnd, 0, MOD_CONTROL/*+MOD_ALT*/,'R');
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_bHelp=1;
	m_voice.SetString("��������� �� ���� �� �����");
	m_voice.Start();

	SetTimer(1,2000,0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CReaderDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CReaderDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CReaderDlg::LoadVoice(CString &vname)
{
	return m_voice.LoadVoice(vname);
}

void CReaderDlg::OnButtonLoad() 
{
	// TODO: Add your control notification handler code here
	CFileDialog LoadDialog(TRUE ,"txt",NULL,OFN_FILEMUSTEXIST|OFN_HIDEREADONLY,
							"Text Documents (*.txt)|*.txt|",this);


	int result=LoadDialog.DoModal();
	if(result==IDOK){
	CString fname;
	fname=LoadDialog.GetPathName();
		if(!fname.IsEmpty()){
			if(LoadText(fname)){
				m_voice.Stop();
				m_voice.SetText(m_pText,m_dwTextSize);
			}
			UpdateUI();
		}
	}
	
}

DWORD CReaderDlg::LoadText(CString &fname)
{
	if(fname.IsEmpty()) return 0;
	DWORD ret=0;
	CFile file;
	if(file.Open(fname, CFile::modeRead))
	{
	FreeText();
	m_sTextFile.Empty();
		DWORD fl=file.GetLength();
		CFileStatus fs;
		file.GetStatus(fname,fs);
		fl=fs.m_size;
		if(fl){
			if(fl>2000000) fl=2000000;
			m_pText=(char*)malloc(fl);
			if(m_pText){
				if((ret=file.Read(m_pText,fl))!=0){
					m_sTextFile=fname;
					m_dwTextSize=ret;
				}
			}
		}
	file.Close();
	}
	return ret;
}

void CReaderDlg::FreeText()
{
	if(m_pText) free(m_pText);
	m_pText=0;
	m_dwTextSize=0;
	m_dwTextPos=0;
}

void CReaderDlg::UpdateUI()
{
	m_staticFile.SetWindowText(m_sTextFile);
}

void CReaderDlg::Play()
{
	if((!m_pText)||(m_dwTextSize==0)||(m_dwTextPos>m_dwTextSize)) return;
	if(m_bHelp){
	m_voice.SetText(m_pText,m_dwTextSize);
	m_voice.SetPosition(m_dwTextPos);
	m_bHelp=0;
	}
	m_voice.Start();
}

void CReaderDlg::OnButtonPlay() 
{
	// TODO: Add your control notification handler code here
	Play();
}

void CReaderDlg::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
}

void CReaderDlg::OnButtonHome() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
	m_voice.SetPosition(0);
	m_voice.Start();
}

void CReaderDlg::OnButtonBack() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
	m_voice.SentenceBack(2);
	Play();
	
}

void CReaderDlg::OnButtonBackm() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
	m_voice.SentenceBack(10);
	Play();
}

void CReaderDlg::OnButtonNext() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
	m_voice.SentenceForth(1);
	Play();	
}

void CReaderDlg::OnButtonNextm() 
{
	// TODO: Add your control notification handler code here
	m_voice.Stop();
	m_voice.SentenceForth(10);
	Play();		
}

void CReaderDlg::UpdateText()
{
	if((!m_pText)||(m_dwTextSize==0))	return;
		DWORD pos=m_voice.GetPosition();
	if(pos>32) pos=pos-32;
	if((pos+2)>=m_dwTextSize)				return;
	DWORD len=m_dwTextSize-pos;
	len=len-1;
	if(len>511) len=511;
	char tt[512];
	MoveMemory(tt,m_pText+pos,len);
	tt[len]=0;
	m_staticText.SetWindowText(tt);
}

void CReaderDlg::OnDestroy() 
{
	if(m_hk1){
	UnregisterHotKey(m_hWnd,0);	
	m_hk1=0;
	}
	KillTimer(1);
	CDialog::OnDestroy();
	// TODO: Add your message handler code here
	
}

void CReaderDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(!m_bHelp) UpdateText();
	CDialog::OnTimer(nIDEvent);
}

BOOL CReaderDlg::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_HOTKEY){
		short ks;
		if ((int)pMsg->wParam==0)
		{
			ks=GetAsyncKeyState('R');
			if(ks&1){
			SetForegroundWindow( );
			}
		}
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CReaderDlg::WinHelp(DWORD dwData, UINT nCmd) 
{
	// TODO: Add your specialized code here and/or call the base class
	m_voice.Stop();
	m_dwTextPos=m_voice.GetPosition();
	m_bHelp=1;
	m_voice.SetString("������� ��� ���������� ... \
		... �� ���� ����� ... ��� �� ��������� �� ����\
		... ��� ��� ����� ... ��� �� ���� ... ��� ��� ������ ... ��� �� ��� �� ����� ... \
		... ��� �� ��� �� ������ ... ��� �� ����");
	m_voice.Start();
	
	//CDialog::WinHelp(dwData, nCmd);
}
