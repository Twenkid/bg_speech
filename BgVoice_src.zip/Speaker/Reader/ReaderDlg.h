// ReaderDlg.h : header file
//

#if !defined(AFX_READERDLG_H__36051006_8D89_11D7_9A56_000000000000__INCLUDED_)
#define AFX_READERDLG_H__36051006_8D89_11D7_9A56_000000000000__INCLUDED_

#include "..\SHARED\Voice.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\\Shared\\Voice.h"

/////////////////////////////////////////////////////////////////////////////
// CReaderDlg dialog

class CReaderDlg : public CDialog
{
// Construction
public:
	void UpdateText();
	void Play();
	void UpdateUI();
	void FreeText();
	DWORD LoadText(CString &fname);
	int LoadVoice(CString &vname);
	CReaderDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CReaderDlg();
// Dialog Data
	//{{AFX_DATA(CReaderDlg)
	enum { IDD = IDD_READER_DIALOG };
	CStatic	m_staticText;
	CStatic	m_staticFile;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReaderDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CVoice m_voice;
	HICON m_hIcon;
	char  *m_pText;
	CString m_sTextFile;
	DWORD m_dwTextSize;
	DWORD m_dwTextPos;
	int   m_bHelp;
	BOOL  m_hk1,m_hk2;

	// Generated message map functions
	//{{AFX_MSG(CReaderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonLoad();
	afx_msg void OnButtonPlay();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonHome();
	afx_msg void OnButtonBack();
	afx_msg void OnButtonBackm();
	afx_msg void OnButtonNext();
	afx_msg void OnButtonNextm();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READERDLG_H__36051006_8D89_11D7_9A56_000000000000__INCLUDED_)
